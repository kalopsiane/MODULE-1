//
//  ViewController.swift
//  CampusConnect
//
//  Created by MacUser on 10/29/26.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TitleLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        TitleLabel.text = "Campus Companion V1"
        // Do any additional setup after loading the view.
    }


}

